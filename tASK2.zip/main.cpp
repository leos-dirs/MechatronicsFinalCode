#include <Arduino.h> // Includes the main Arduino library so we can use functions like pinMode(), digitalWrite(), analogRead(), delay(), millis(), and Serial.
#include <math.h>    // Includes the math library so we can use functions like log(), which is needed for the thermistor temperature equation.
#include <WiFi.h>    // Includes the WiFi library so the ESP32 can connect to the router and host a local webpage.

const char* ssid = "ilovemechatronics"; // Stores the WiFi network name that the ESP32 will connect to.
const char* password = "Spring26";      // Stores the WiFi password that allows the ESP32 to connect to the network.

WiFiServer server(80); // Creates a web server object on port 80, which is the standard HTTP webpage port.

#define PIN_ANALOG_IN 1 // Defines GPIO pin 1 as the analog input pin where the thermistor voltage divider output is read.
#define PIN_BUZZER 14   // Defines GPIO pin 14 as the digital output pin that controls the buzzer.

double beta = 3950.0; // Stores the thermistor beta value, which describes how resistance changes with temperature.
double R = 8.22;      // Stores the known resistor value in kOhms used in the voltage divider circuit.
double Ti = 25.0;     // Stores the reference temperature in Celsius, which is usually 25 C for thermistor calculations.
double Vsup = 3.3;    // Stores the ESP32 supply/reference voltage used by the voltage divider and ADC calculation.
double TroomF = 75.0; // Stores the assumed room temperature in Fahrenheit.
double maxTover = 5.0; // Stores the allowed temperature rise above room temperature before the alarm turns on.
double Tlim = TroomF + maxTover; // Calculates the alarm limit temperature by adding the allowed rise to room temperature.

String AlarmState = "Off"; // Creates a string variable to store whether the alarm is currently on or off.
String Temperature = "";   // Creates a string variable to store the current measured temperature for the webpage.
String header;             // Creates a string variable to store the incoming HTTP request from the webpage client.

unsigned long currentTime = millis(); // Stores the current time from the ESP32 internal clock in milliseconds.
unsigned long previousTime = 0;       // Stores the previous time used to track client timeout.
const long timeoutTime = 2000;        // Sets the maximum amount of time the ESP32 will wait for a web client request before timing out.

unsigned long lastTempUpdate = 0; // Stores the last time the temperature calculation was updated.
const unsigned long tempUpdateInterval = 500; // Sets the temperature update interval to 500 ms so the sensor is not constantly recalculated every loop.

double tempF = 0.0; // Creates a global variable to store the calculated temperature in Fahrenheit.

void updateTemperatureAndAlarm() { // Creates a function that reads the thermistor, calculates temperature, and controls the buzzer.
  if (millis() - lastTempUpdate < tempUpdateInterval) { // Checks if less than 500 ms has passed since the last temperature update.
    return; // Leaves the function early so the temperature calculation only happens at the chosen time interval.
  }

  lastTempUpdate = millis(); // Updates the last temperature reading time to the current time.

  int adcValue = analogRead(PIN_ANALOG_IN); // Reads the analog voltage from the thermistor voltage divider as an ADC value from 0 to 4095.
  double voltage = (float)adcValue / 4095.0 * Vsup; // Converts the ADC value into an actual voltage between 0 and 3.3 V.

  if (voltage <= 0.0 || voltage >= Vsup) { // Checks for an impossible or unsafe voltage reading that would break the resistance calculation.
    Temperature = "Sensor Error"; // Sets the webpage temperature display to show that the sensor reading is invalid.
    AlarmState = "ON!"; // Turns the alarm state on because a failed sensor should be treated as unsafe.
    digitalWrite(PIN_BUZZER, HIGH); // Sends HIGH to the buzzer pin, turning the buzzer on.
    Serial.printf("Sensor error | ADC: %d | Voltage: %.3f V\n", adcValue, voltage); // Prints the error information to the serial monitor for debugging.
    return; // Leaves the function early because the temperature calculation cannot be trusted.
  }

  double Rt = R * voltage / (Vsup - voltage); // Uses the voltage divider equation to solve for the thermistor resistance in kOhms.
  double tempK = 1.0 / (1.0 / (273.15 + Ti) + log(Rt / R) / beta); // Uses the thermistor beta equation to calculate temperature in Kelvin.
  double tempC = tempK - 273.15; // Converts temperature from Kelvin to Celsius.
  tempF = 32.0 + tempC * 9.0 / 5.0; // Converts temperature from Celsius to Fahrenheit.
  double tempVsLim = tempF - Tlim; // Calculates how far the current temperature is above or below the alarm limit.

  Temperature = String(tempF, 2) + " F"; // Converts the Fahrenheit temperature into a string with two decimal places for the webpage.

  if (tempF > Tlim) { // Checks if the measured temperature is greater than the allowed temperature limit.
    digitalWrite(PIN_BUZZER, HIGH); // Turns the buzzer on because the temperature is too high.
    AlarmState = "ON!"; // Updates the alarm state so the webpage shows that the alarm is active.
    Serial.printf("Temperature is too high!!, Currently %.2fF over the limit!\n", tempVsLim); // Prints how far over the limit the temperature is.
  } else { // Runs if the measured temperature is not above the temperature limit.
    digitalWrite(PIN_BUZZER, LOW); // Turns the buzzer off because the system is within the safe temperature range.
    AlarmState = "Off"; // Updates the alarm state so the webpage shows that the alarm is off.
    Serial.printf("All good, Temp is under the limit %.2fF\n", Tlim); // Prints that the system is below the alarm limit.
  }

  Serial.printf("ADC: %d | Voltage: %.3f V | Rt: %.3f kOhm | Temp: %.2f F\n",
                adcValue, voltage, Rt, tempF); // Prints the raw ADC value, voltage, thermistor resistance, and calculated temperature for debugging.
}

void handleWebClient() { // Creates a function that handles webpage requests from a connected client.
  WiFiClient client = server.available(); // Checks if a phone, laptop, or other device is trying to connect to the ESP32 webpage.

  if (client) { // Runs only if a client has connected to the ESP32 web server.
    currentTime = millis(); // Records the current time when the client connects.
    previousTime = currentTime; // Sets the previous time equal to the current time to start the timeout counter.

    Serial.println("New Client."); // Prints to the serial monitor that a new web client connected.

    String currentLine = ""; // Creates a string to store the current line of the HTTP request.

    while (client.connected() && currentTime - previousTime <= timeoutTime) { // Keeps reading the request while the client is connected and has not timed out.
      currentTime = millis(); // Updates the current time during the client connection.

      if (client.available()) { // Checks if the client has sent data to the ESP32.
        char c = client.read(); // Reads one character from the client's HTTP request.

        Serial.write(c); // Prints the received character to the serial monitor so the request can be viewed.
        header += c; // Adds the received character to the header string.

        if (c == '\n') { // Checks if the character is a newline, meaning the end of a line in the HTTP request.
          if (currentLine.length() == 0) { // Checks if the current line is blank, which means the HTTP request has ended.
            client.println("HTTP/1.1 200 OK"); // Sends an HTTP response code telling the browser the request was successful.
            client.println("Content-type:text/html"); // Tells the browser that the response is an HTML webpage.
            client.println("Connection: close"); // Tells the browser that the connection will close after the response is sent.
            client.println(); // Sends a blank line required before the actual HTML content starts.

            client.println("<!DOCTYPE html><html>"); // Starts the HTML document.
            client.println("<head>"); // Starts the head section of the webpage.
            client.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"); // Makes the webpage scale correctly on phones and different screen sizes.
            client.println("<meta http-equiv=\"refresh\" content=\"2\">"); // Refreshes the webpage every 2 seconds so the temperature display updates.
            client.println("<link rel=\"icon\" href=\"data:,\">"); // Prevents the browser from requesting a favicon icon.

            client.println("<style>"); // Starts the CSS style section for the webpage.
            client.println("html { font-family: Helvetica; text-align: center; margin-top: 50px; }"); // Sets the font, centers the text, and adds spacing from the top.
            client.println(".button { background-color: #4CAF50; border: none; color: white; padding: 16px 40px;"); // Defines a button style, although this current webpage does not use a button.
            client.println("text-decoration: none; font-size: 30px; margin: 10px; cursor: pointer; border-radius: 8px; }"); // Continues the button styling.
            client.println(".buttonOff { background-color: #555555; }"); // Defines a second button style for an off button, although it is not currently used.
            client.println("</style>"); // Ends the CSS style section.

            client.println("<title>On Shore Control Station</title>"); // Sets the title shown in the browser tab.
            client.println("</head>"); // Ends the head section.

            client.println("<body>"); // Starts the visible body section of the webpage.
            client.println("<h1>On Shore Control Station</h1>"); // Displays the main webpage heading.
            client.println("<p>Temperature Alarm State: " + AlarmState + "</p>"); // Displays whether the alarm is currently on or off.
            client.println("<p>Temperature: " + Temperature + "</p>"); // Displays the current measured temperature.
            client.println("<p>Limit: " + String(Tlim, 2) + " F</p>"); // Displays the temperature limit used to trigger the alarm.
            client.println("</body></html>"); // Ends the body and HTML document.

            client.println(); // Sends a final blank line to finish the HTTP response.
            break; // Exits the while loop because the webpage has been sent to the client.
          } else { // Runs when a newline is received but the current line was not blank.
            currentLine = ""; // Clears the current line so the next line of the HTTP request can be read.
          }
        } else if (c != '\r') { // Checks that the character is not a carriage return.
          currentLine += c; // Adds the character to the current line string.
        }
      }
    }

    header = ""; // Clears the stored HTTP header so it does not affect the next client request.
    client.stop(); // Closes the connection with the web client.

    Serial.println("Client disconnected."); // Prints that the client has disconnected.
    Serial.println(); // Prints a blank line for readability in the serial monitor.
  }
}

void setup() { // Creates the setup function, which runs once when the ESP32 first powers on or resets.
  Serial.begin(115200); // Starts serial communication at 115200 baud so we can view debug messages in the serial monitor.
  delay(3000); // Waits 3 seconds to give the serial monitor time to connect after startup.

  Serial.println("\n\n===== NEW CODE STARTED ====="); // Prints a clear startup message so we know the ESP32 restarted and is running the newest uploaded code.

  pinMode(PIN_BUZZER, OUTPUT); // Sets the buzzer pin as an output because the ESP32 will control it.
  digitalWrite(PIN_BUZZER, LOW); // Starts the buzzer off so the alarm is not active immediately on boot.

  Serial.println("Starting WiFi setup..."); // Prints that the WiFi setup process is beginning.

  Serial.println(); // Prints a blank line for readability.
  Serial.println("ESP32 booted."); // Prints that the ESP32 has successfully booted.
  Serial.print("Connecting to "); // Prints the beginning of the WiFi connection message.
  Serial.println(ssid); // Prints the WiFi network name the ESP32 is trying to connect to.

  WiFi.begin(ssid, password); // Starts the WiFi connection using the provided network name and password.

  while (WiFi.status() != WL_CONNECTED) { // Keeps looping while the ESP32 is not connected to WiFi.
    delay(500); // Waits half a second between connection checks.
    Serial.print("."); // Prints dots to show that the ESP32 is still trying to connect.
  }

  Serial.println(); // Prints a blank line after the WiFi connection dots.
  Serial.println("WiFi connected."); // Prints that the ESP32 successfully connected to the network.
  Serial.print("IP address: "); // Prints a label before showing the ESP32 IP address.
  Serial.println(WiFi.localIP()); // Prints the local IP address used to access the webpage.

  server.begin(); // Starts the web server so clients can connect to the ESP32 webpage.
}

void loop() { // Creates the main loop function, which runs repeatedly after setup finishes.
  updateTemperatureAndAlarm(); // Continuously updates the thermistor reading and buzzer alarm logic.
  handleWebClient(); // Continuously checks for webpage clients and sends the current alarm information when requested.
}